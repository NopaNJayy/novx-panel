// === Splash Screen ===
function closeSplash() {
    document.getElementById('splash').classList.add('hidden');
}

// Generate splash particles
(function initSplashParticles() {
    const container = document.getElementById('splash-particles');
    if (!container) return;
    for (let i = 0; i < 40; i++) {
        const s = document.createElement('div');
        s.className = 'spark';
        s.style.left = Math.random() * 100 + '%';
        s.style.top = Math.random() * 100 + '%';
        s.style.setProperty('--tx', (Math.random() - 0.5) * 300 + 'px');
        s.style.setProperty('--ty', (Math.random() - 0.5) * 300 + 'px');
        s.style.animationDelay = Math.random() * 4 + 's';
        s.style.animationDuration = 3 + Math.random() * 3 + 's';
        s.style.background = Math.random() > 0.5 ? 'var(--accent)' : 'var(--accent2)';
        s.style.width = s.style.height = (2 + Math.random() * 4) + 'px';
        container.appendChild(s);
    }
})();

// === Navbar Scroll ===
const nav = document.getElementById('nav');
window.addEventListener('scroll', () => {
    nav.classList.toggle('scrolled', window.scrollY > 60);
});

// Active nav link on scroll
const secs = document.querySelectorAll('section');
const links = document.querySelectorAll('.nav-menu a');
window.addEventListener('scroll', () => {
    let cur = '';
    secs.forEach(s => { if (window.scrollY >= s.offsetTop - 200) cur = s.id; });
    links.forEach(a => {
        a.classList.toggle('active', a.getAttribute('href') === '#' + cur);
    });
});

// Smooth scroll
document.querySelectorAll('a[href^="#"]').forEach(a => {
    a.addEventListener('click', e => {
        e.preventDefault();
        const t = document.querySelector(a.getAttribute('href'));
        if (t) window.scrollTo({ top: t.offsetTop - 80, behavior: 'smooth' });
    });
});

// === Background Particles ===
const canvas = document.getElementById('bg-canvas');
const ctx = canvas.getContext('2d');
let particles = [];

function resize() {
    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;
}
resize();
window.addEventListener('resize', resize);

class Dot {
    constructor() { this.init(); }
    init() {
        this.x = Math.random() * canvas.width;
        this.y = Math.random() * canvas.height;
        this.r = Math.random() * 2 + 0.5;
        this.vx = (Math.random() - 0.5) * 0.4;
        this.vy = (Math.random() - 0.5) * 0.4;
        this.alpha = Math.random() * 0.4 + 0.05;
        this.color = Math.random() > 0.6 ? '0,229,255' : '124,77,255';
    }
    update() {
        this.x += this.vx;
        this.y += this.vy;
        if (this.x < 0 || this.x > canvas.width) this.vx *= -1;
        if (this.y < 0 || this.y > canvas.height) this.vy *= -1;
    }
    draw() {
        ctx.fillStyle = `rgba(${this.color},${this.alpha})`;
        ctx.beginPath();
        ctx.arc(this.x, this.y, this.r, 0, Math.PI * 2);
        ctx.fill();
    }
}

function initDots() {
    particles = [];
    const n = Math.min(Math.floor((canvas.width * canvas.height) / 12000), 150);
    for (let i = 0; i < n; i++) particles.push(new Dot());
}

function drawLines() {
    for (let i = 0; i < particles.length; i++) {
        for (let j = i + 1; j < particles.length; j++) {
            const dx = particles[i].x - particles[j].x;
            const dy = particles[i].y - particles[j].y;
            const d = Math.sqrt(dx * dx + dy * dy);
            if (d < 120) {
                ctx.strokeStyle = `rgba(0,229,255,${0.06 * (1 - d / 120)})`;
                ctx.lineWidth = 0.5;
                ctx.beginPath();
                ctx.moveTo(particles[i].x, particles[i].y);
                ctx.lineTo(particles[j].x, particles[j].y);
                ctx.stroke();
            }
        }
    }
}

function animate() {
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    particles.forEach(p => { p.update(); p.draw(); });
    drawLines();
    requestAnimationFrame(animate);
}

initDots();
animate();

// === Scroll Reveal ===
const observer = new IntersectionObserver(entries => {
    entries.forEach(e => { if (e.isIntersecting) e.target.classList.add('vis'); });
}, { threshold: 0.1, rootMargin: '0px 0px -40px 0px' });
document.querySelectorAll('.reveal').forEach(el => observer.observe(el));

// === Buy Flow ===
let pendingItem = '';

function buyItem(name) {
    pendingItem = name;
    document.getElementById('dc-prompt').classList.add('open');
}

function closeDC() {
    document.getElementById('dc-prompt').classList.remove('open');
}

function openQR() {
    document.getElementById('m-product').textContent = pendingItem;
    document.getElementById('qr-modal').classList.add('open');
}

function closeQR() {
    document.getElementById('qr-modal').classList.remove('open');
}

// Close modals on bg click
document.querySelectorAll('.modal-bg').forEach(m => {
    m.addEventListener('click', e => { if (e.target === m) m.classList.remove('open'); });
});
